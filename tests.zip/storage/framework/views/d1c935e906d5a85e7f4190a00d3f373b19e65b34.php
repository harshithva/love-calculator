<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Love Calculator</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/argon.css')); ?>" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-light bg-primary">
        <a class="navbar-brand text-white" href="<?php echo e(route('home')); ?>">
            
            <i class="fas fa-heart text-white"></i>&nbsp;
            Love Calculator
        </a>
    </nav>

    <div class="container-fluid mt-3">
        <div class="progress-wrapper">
            <div class="progress-primary">
                <div class="progress-label">
                    <span>Compatibility</span>
                </div>
                <div class="progress-percentage">
                    <span><?php echo e($response->percentage); ?></span>
                </div>
            </div>
            <div class="row">
                <div class="col text-center">
                    <h1><?php echo e($response->percentage); ?>%</h1>
                </div>
            </div>
            <?php if($response->percentage <=20): ?> <div class="progress">
                <div class="progress-bar bg-danger" role="progressbar" aria-valuenow="<?php echo e($response->percentage); ?>"
                    aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($response->percentage); ?>%;"></div>
        </div>

        <?php elseif($response->percentage <=50): ?> <div class="progress">
            <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="<?php echo e($response->percentage); ?>"
                aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($response->percentage); ?>%;"></div>
    </div>
    <?php elseif($response->percentage <=80): ?> <div class="progress">
        <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="<?php echo e($response->percentage); ?>"
            aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($response->percentage); ?>%;"></div>
        </div>
        <?php else: ?>
        <div class="progress">
            <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($response->percentage); ?>"
                aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($response->percentage); ?>%;"></div>
        </div>
        <?php endif; ?>

        </div>


        <div class="jumbotron text-center">
            <p><?php echo e($response->result); ?></p>
            <h1 class="display-3">Thank You!</h1>
            <p class="lead">
                <a class="btn btn-primary btn-lg btn-block" href="<?php echo e(route('home')); ?>" role="button">Calculate Again</a>
            </p>
        </div>
        </div>
        <script src="https://kit.fontawesome.com/94f4252744.js" crossorigin="anonymous"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\love-calculator\resources\views/result.blade.php ENDPATH**/ ?>