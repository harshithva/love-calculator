<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Love extends Model
{
    protected $fillable = ["name_1","name_2","perc"];
}
